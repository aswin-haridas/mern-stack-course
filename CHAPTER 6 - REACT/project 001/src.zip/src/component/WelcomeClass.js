import React, { Component } from "react";

class MyWeclomeClass extends Component {
    render() {
        return <h1>{this.props.firstName}</h1>
    }
}


export default MyWeclomeClass;