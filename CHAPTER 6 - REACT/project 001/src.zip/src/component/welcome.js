import React from 'react'

function Welcome(prop) {
    return <h1>Hello, {prop.firstName}</h1>
}


export default Welcome