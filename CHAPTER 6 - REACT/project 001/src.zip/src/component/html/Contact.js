function Contact() {
    return (
          <div>
               <h1>Welcome to Contact Page</h1>
               <p>This is the Contact page of the application.</p>
          </div>
     );
}

export default Contact;
