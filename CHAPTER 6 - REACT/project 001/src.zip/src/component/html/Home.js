import React from "react";

function Home() {
    return (
          <div>
               <h1>Welcome to Home Page</h1>
               <p>This is the home page of the application.</p>
          </div>
     );
}

export default Home;
