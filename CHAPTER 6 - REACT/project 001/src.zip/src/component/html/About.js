function About() {
    return (
          <div>
               <h1>Welcome to About Page</h1>
               <p>This is the About page of the application.</p>
          </div>
     );
}

export default About;
