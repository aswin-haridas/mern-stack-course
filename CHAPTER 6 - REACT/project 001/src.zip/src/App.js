

import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './component/html/Home'
import About from './component/html/About'
import Mypage from './component/Mypage'
function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/" exact element={<Mypage/>} />
          <Route path="/home" element={<Home/>} />
          <Route path="/about" element={<About/>} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}
export default App;